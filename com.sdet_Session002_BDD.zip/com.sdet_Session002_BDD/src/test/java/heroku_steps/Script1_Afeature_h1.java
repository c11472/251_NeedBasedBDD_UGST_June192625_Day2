package heroku_steps;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import junit.framework.Assert;

public class Script1_Afeature_h1 {
	
	WebDriver driver; // Interface
	
	
	  By unm = By.id("txt-username");
	  By pwd = By.id("txt-password");
	  By lgin = By.id("btn-login");
	  
	  By textvalidate = By.xpath("//h2[contains(text(),'Make Appointment')]");
	  
	  String exp_text = "Make Appointment";
	  
	  String act_text;
	
	
	    @Given("I am in login page")
	    public void I_am_in_login_page() {
	    	driver = new ChromeDriver();
	    	driver.get("https://katalon-demo-cura.herokuapp.com/profile.php#login");
	    	
	    	
	    }
	    
	    
	    @When("I eneter user name")
	    public void I_eneter_user_name(){
	    	 driver.findElement(unm).sendKeys("John Doe"); // call the method

	    }
	    @When("I enter password")
	    public void I_enter_password() {
	    	driver.findElement(pwd).sendKeys("ThisIsNotAPassword");// call the method from lib
	    	
	    	
	    	
	    }
	    @And("I click on login")
	    public void I_click_on_login() {
	    	driver.findElement(lgin).click();
	    	
	    }
	    @Then("I am in account login page")
	    public void I_am_in_account_login_page(){
	    	 act_text = driver.findElement(textvalidate).getText();
	    	 Assert.assertEquals(exp_text,act_text);
	      	
	    }
}
