package HomePageLib_Heroku;
/****
 * 
 * Understanding Assertion - Assert in TestNG
 */
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

/*
 * Testcase : Login
Access the login page https://katalon-demo-cura.herokuapp.com/profile.php#login.
Enter the username
Enter the password
Click on Login
Validate
 * 
 * 
 */

public class Testcase_001_HomePLib1 {
	
	
	WebDriver driver; // Interface
	
	
	  By unm = By.id("txt-username");
	  By pwd = By.id("txt-password");
	  By lgin = By.id("btn-login");
	  
	  By textvalidate = By.xpath("//h2[contains(text(),'Make Appointment')]");
	  
	  String act_text;
	  
	// Driver init
	public void init(WebDriver driver) {
		this.driver=driver;
		//driver = new ChromeDriver();
	}
	
	// This method returns the dynamic value at the time of execution
	
	public String LoginPageAccess() 
	{
		 driver.get("https://katalon-demo-cura.herokuapp.com/profile.php#login");
		 driver.findElement(unm).sendKeys("John Doe");
		 driver.findElement(pwd).sendKeys("ThisIsNotAPassword");
		 driver.findElement(lgin).click();
		 act_text = driver.findElement(textvalidate).getText();
		 
		 return act_text; // dynamic data
 
	}
	
	
	
	
	

}
