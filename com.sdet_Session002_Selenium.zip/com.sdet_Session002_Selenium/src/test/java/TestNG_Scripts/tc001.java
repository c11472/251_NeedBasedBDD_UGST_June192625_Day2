package TestNG_Scripts;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import HomePageLib_Heroku.Testcase_001_HomePLib1;
import junit.framework.Assert;

public class tc001 {
	
	WebDriver driver = new ChromeDriver();
  
  Testcase_001_HomePLib1 o1 = new Testcase_001_HomePLib1();
  
  
  
  

  
  @Test(priority=1)
  public void LaunchLoginTest() {
	  // launch
	  String exp_text = "Make Appointment45"; // hidden --- Excel , properties
	  o1.init(driver);
	  
	 
	 // perform login
	 String act_txt1= o1.LoginPageAccess();
	 System.out.println(act_txt1); // capturing the data
	 
	 
	 // Why Assertion 
	 
	 Assert.assertEquals(exp_text, act_txt1); //passed
	 
	 
	 System.out.println("dummy val");
	  
	 
	
  }
  
  
}
